# KarachiZameen Full Stack Web App

A full-stack property listing web application built using Flask (Python) and HTML/Tailwind frontend.

## Features
- Add / Delete property listings
- Dynamic filters and search
- Live price insights
- Data persistence (JSON)
- Responsive Tailwind UI

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the backend:
   ```bash
   python shayan.py
   ```
3. Open the site:
   ```bash
   http://127.0.0.1:5000
   ```

## Folder Structure
```
shayan.py                → Flask backend
KarachiZameen.html       → Frontend website
properties.json          → Data storage (auto-created)
```
