from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import json
import os

app = Flask(__name__, static_folder=".", static_url_path="")
CORS(app)

DATA_FILE = "properties.json"

if os.path.exists(DATA_FILE):
    with open(DATA_FILE, "r") as f:
        properties = json.load(f)
else:
    properties = []

@app.route("/")
def index():
    return send_from_directory(".", "KarachiZameen.html")

@app.route("/api/properties", methods=["GET"])
def get_properties():
    return jsonify(properties)

@app.route("/api/properties", methods=["POST"])
def add_property():
    new_property = request.json
    new_property["id"] = str(len(properties) + 1)
    properties.append(new_property)
    save_data()
    return jsonify({"success": True, "message": "Property added successfully"}), 201

@app.route("/api/properties/<string:pid>", methods=["DELETE"])
def delete_property(pid):
    global properties
    properties = [p for p in properties if p["id"] != pid]
    save_data()
    return jsonify({"success": True, "message": "Property deleted successfully"})

def save_data():
    with open(DATA_FILE, "w") as f:
        json.dump(properties, f, indent=4)

if __name__ == "__main__":
    app.run(debug=True)
